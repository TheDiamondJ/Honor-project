<template>
    <div style="height: 800px;width: 1280px; margin: auto;">
        <el-row style="width: 100%">
            <el-col :span="4">
                <div style="background-color: #2F3744 ;height: 80px;color: white;display: flex">
                    <div style="padding-top: 20px;padding-left: 20px">Welcome: Tourists
                        <el-divider direction="vertical" content-position="center"></el-divider>
                    </div>
                </div>
            </el-col>
            <el-col :span="20">
                <div style="background-color: #2F3744 ;height: 80px">
                    <el-select v-model="typeId" clearable @change="changeType"
                               style="width: 200px;margin-top: 20px;margin-left: 20px"
                    >
                        <el-option
                                v-for="item in types"
                                :key="item.id"
                                :label="item.name"
                                :value="item.id">
                        </el-option>
                    </el-select>
                    <el-input
                            style="width: 160px;margin-top: 20px;margin-left: 520px;background-color: #2F3744"
                            suffix-icon="el-icon-search"
                            @change="search"
                            v-model="searchValue">
                    </el-input>
                </div>
            </el-col>
        </el-row>
        <el-row style="width: 100%;height: 720px">
            <el-col :span="4">
                <div style="background-color: #2F3744 ;height: 720px">
                    <div style="margin-left: 20px">
                        <el-button type="success" @click="login" v-if="this.user == null" size="mini">Sign in
                        </el-button>
                        <el-button type="success" @click="register" v-if="this.user == null" size="mini">Register
                        </el-button>
                        <el-button type="success" @click="logout" v-if="this.user != null" size="mini">Sign out
                        </el-button>
                    </div>
                    <div style="margin:23px">
                        <el-avatar :size="150" v-if="this.user==null" src="http://localhost:8888/upload/default.jpg"></el-avatar>
                        <el-avatar :size="150" v-if="this.user!=null" :src="this.user.avatar"></el-avatar>

                        <el-divider></el-divider>
                    </div>
                    <div style="color: white;margin-top: 30px;margin-left: 20px">
                        <p>station number: A1001</p>
                        <p style="margin-top: 30px">people number: 9</p>
                        <p style="margin-top: 30px" v-if="this.user != null">username: {{this.user.username}}</p>
                    </div>

                </div>
            </el-col>
            <el-col :span="20">
                <div style="background-color: white ;height: 720px">
                    <el-row :gutter="20">
                        <el-col :span="10">
                            <div style="height: 400px;width: 400px">
                                <el-card shadow="hover" v-if="count>=1" @click.native="routTo(data[0].id)">
                                    <el-image
                                        style="width: 360px; height: 360px"
                                        :src="data[0].image"
                                        fit="fill"></el-image>
                                    <div style="margin-top: -5px;background-color: rgba(128, 128, 128);width: 360px;height: 50px;color: white;font-size: 12px">
                                        <span style="margin: 20px">{{ data[0].name }}</span>
                                        <br>
                                        <span style="margin: 20px">￡{{ data[0].price }}</span>
                                    </div>
                                </el-card>
                            </div>

                        </el-col>
                        <el-col :span="5">
                            <el-row>
                                <div style="height: 160px;width: 180px">
                                    <el-card shadow="hover" v-if="count>=2" @click.native="routTo(data[1].id)">
                                        <el-image
                                            style="width: 140px; height: 120px"
                                            :src="data[1].image"
                                            fit="fill"></el-image>
                                        <div style="margin-top: -5px;background-color: rgba(128, 128, 128);width: 140px;height: 50px;color: white;font-size: 12px">
                                            <span style="margin: 20px">{{data[1].name}}</span>
                                            <br>
                                        <span style="margin: 20px">￡{{ data[1].price }}</span>
                                        </div>
                                    </el-card>
                                </div>
                            </el-row>
                            <br><br><br>
                            <el-row>
                                <div style="height: 160px;width: 180px">
                                    <el-card shadow="hover" v-if="count>=3" @click.native="routTo(data[2].id)">
                                        <el-image
                                            style="width: 140px; height: 120px"
                                            :src="data[2].image"
                                            fit="fill"></el-image>
                                        <div style="margin-top: -5px;background-color: rgba(128, 128, 128);width: 140px;height: 50px;color: white;font-size: 12px">
                                            <span style="margin: 20px">{{data[2].name}}</span>
                                            <br>
                                        <span style="margin: 20px">￡{{data[2].price}}</span>
                                        </div>
                                    </el-card>
                                </div>
                            </el-row>

                        </el-col>
                        <el-col :span="7">
                            <div style="height: 400px;width: 300px">
                                <el-card shadow="hover" v-if="count>=4" @click.native="routTo(data[3].id)">
                                    <el-image
                                        style="width: 260px; height: 360px"
                                        :src="data[3].image"
                                        fit="fill"></el-image>
                                    <div style="margin-top: -5px;background-color: rgba(128, 128, 128);width: 260px;height: 50px;color: white;font-size: 12px">
                                        <span style="margin: 20px">{{data[3].name}}</span>
                                        <br>
                                        <span style="margin: 20px">￡{{data[3].price}}</span>
                                    </div>
                                </el-card>
                            </div>
                        </el-col>
                    </el-row>
                    <el-row :gutter="20">
                        <el-col :span="6">
                            <div style="height: 160px;width: 160px;padding-top: 70px">
                                <el-card shadow="hover" v-if="count>=5" @click.native="routTo(data[4].id)">
                                    <el-image
                                        style="width: 120px; height: 120px"
                                        :src="data[4].image"
                                        fit="fill"></el-image>
                                    <div style="margin-top: -5px;background-color: rgba(128, 128, 128);width: 120px;height: 50px;color: white;font-size: 12px;font-size: 12px">
                                        <span style="margin: 20px">{{data[4].name}}</span>
                                        <br>
                                        <span style="margin: 20px">￡{{data[4].price}}</span>
                                    </div>
                                </el-card>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div style="height: 160px;width: 160px;padding-top: 70px">
                                <el-card shadow="hover" v-if="count>=6" @click.native="routTo(data[5].id)">
                                    <el-image
                                        style="width: 120px; height: 120px"
                                        :src="data[5].image"
                                        fit="fill"></el-image>
                                    <div style="margin-top: -5px;background-color: rgba(128, 128, 128);width: 120px;height: 50px;color: white;font-size: 12px">
                                        <span style="margin: 20px">{{data[5].name}}</span>
                                        <br>
                                        <span style="margin: 20px">￡{{data[5].price}}</span>
                                    </div>
                                </el-card>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div style="height: 160px;width: 160px;padding-top: 70px">
                                <el-card shadow="hover" v-if="count>=7" @click.native="routTo(data[6].id)">
                                    <el-image
                                        style="width: 120px; height: 120px"
                                        :src="data[6].image"
                                        fit="fill"></el-image>
                                    <div style="margin-top: -5px;background-color: rgba(128, 128, 128);width: 120px;height: 50px;color: white;font-size: 12px">
                                        <span style="margin: 20px">{{data[6].name}}</span>
                                        <br>
                                        <span style="margin-left: 20px">￡{{data[6].price}}</span>
                                    </div>
                                </el-card>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div style="height: 160px;width: 160px;padding-top: 70px">
                                <el-card shadow="hover" v-if="count>=8" @click.native="routTo(data[7].id)">
                                    <el-image
                                        style="width: 120px; height: 120px"
                                        :src="data[7].image"
                                        fit="fill"></el-image>
                                    <div style="margin-top: -5px;background-color: rgba(128, 128, 128);width: 120px;height: 50px;color: white;font-size: 12px">
                                        <span style="margin: 20px">{{data[7].name}}</span>
                                        <br>
                                        <span style="margin: 20px">￡{{data[7].price}}</span>
                                    </div>
                                </el-card>
                            </div>
                        </el-col>
                    </el-row>
                        <div style="margin-top: 60px;margin-left: 200px" >
                            <el-pagination
                                background
                                layout="prev, pager, next"
                                :page-size="size"
                                :current-page.sync="currentPage"
                                @current-change="handleCurrentChange"
                                :total="total">
                            </el-pagination>
                        </div>
                </div>
            </el-col>
        </el-row>


        <el-dialog title="Sign in" :visible.sync="dialogFormVisible" center>

            <el-form :model="loginForm" status-icon :rules="rules" ref="loginForm" label-width="100px" class="ruleForm">

                <el-form-item label="username" prop="username">
                    <el-input v-model="loginForm.username"></el-input>
                </el-form-item>

                <el-form-item label="password" prop="password">
                    <el-input type="password" v-model="loginForm.password" auto-complete="off"></el-input>
                </el-form-item>
            </el-form>

            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false; resetForm('loginForm')">cancel</el-button>
                <el-button type="primary" @click="confirm">sign in</el-button>
            </div>
        </el-dialog>

        <el-dialog
                title="Register"
                :visible.sync="centerDialogVisible"
                width="40%"
                center>

            <el-form ref="form" :rules="rules1" :model="form" label-width="100px">
                <el-form-item label="username" prop="username">
                    <el-col :span="20">
                        <el-input v-model="form.username"></el-input>
                    </el-col>
                </el-form-item>
                <el-form-item label="password" prop="password">
                    <el-col :span="20">
                        <el-input v-model="form.password"></el-input>
                    </el-col>
                </el-form-item>
                <el-form-item label="avatar" prop="avatar">
                    <el-col :span="20">
                        <el-upload action="http://localhost:8888/upload"
                                   list-type="picture-card"
                                   :on-preview="preview"
                                   :on-success="handleSuccess"
                                   :limit="1"
                                   :before-upload="beforeUpload">

                            <i class="el-icon-plus"></i>
                        </el-upload>
                    </el-col>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="centerDialogVisible = false">cancel</el-button>
                <el-button type="primary" @click="doSave">confirm</el-button>
            </span>
        </el-dialog>
    </div>
</template>


<script>

import it from "element-ui/src/locale/lang/it";
export default {
    name: "index",
    computed: {
        it() {
            return it
        }
    },
    data() {
        let checkDuplicate = (rule, value, callback) => {
            if (this.form.id) {
                return callback();
            }
            this.$axios.get(this.$httpUrl + "/user/find/username?username=" + this.form.username).then(res => res.data).then(res => {
                if (res.code != 200) {
                    callback()
                } else {
                    callback(new Error('username already exists'));
                }
            })
        };
        return {
            typeId: '',
            types: [],
            menuIndex: 1,
            data: [],
            count: 0,
            user: null,
            dialogFormVisible: false,
            centerDialogVisible: false,
            size: 8,
            page: 1,
            total: 0,
            currentPage: 1,
            loginForm: {
                username: '',
                password: ''
            },
            rules: {
                username: [
                    {required: true, message: 'please enter username', trigger: 'blur'}
                ],
                password: [
                    {required: true, message: 'please enter password', trigger: 'blur'}
                ]
            },
            form: {
                id: '',
                username: '',
                password: '',
                avatar: ''
            },
            rules1: {
                username: [
                    {required: true, message: 'Please enter username', trigger: 'blur'},
                    {min: 3, max: 8, message: '3 to 8 characters long', trigger: 'blur'},
                    {validator: checkDuplicate, trigger: 'blur'}
                ],
                password: [
                    {required: true, message: 'Please enter password', trigger: 'blur'},
                    {min: 3, max: 8, message: '3 to 8 characters long', trigger: 'blur'}
                ],
            },
            searchValue: ''
        }
    },
    methods: {
        handleSuccess(res, file) {
            console.log(file.url)
            this.form.avatar = res.data

        },
        preview(file) {
            console.log(file)
        },
        routTo(id){
            this.$router.push({
                name: 'detail',
                params: {
                    id: id
                }
            })
        },
        beforeUpload(file) {

            const isJPG = file.type === 'image/jpeg';
            const isPNG = file.type === 'image/png';
            const isLt2M = file.size / 1024 / 1024 < 2;

            if (!isJPG && !isPNG) {
                this.$message.error('Upload pictures can only be in JPG or PNG format!');
            }
            if (!isLt2M) {
                this.$message.error('Upload pictures cannot exceed 2MB in size!');
            }
            return (isJPG || isPNG) && isLt2M;
        },
        logout() {
            console.log('logout')
            this.$confirm('Are you sure you want to log out??', 'prompt', {
                confirmButtonText: 'confirm',
                cancelButtonText: 'cancel',
                type: 'warning',
                center: true,

            })
                .then(() => {
                    this.$message({
                        type: 'success',
                        message: 'exit successfully'
                    })

                    this.$router.push("/")
                    this.user = null
                    this.resetForm('loginForm')
                    sessionStorage.clear()
                })
                .catch(() => {
                    this.$message({
                        type: 'info',
                        message: 'cancel exit'
                    })
                })
        },
        handleCurrentChange(val) {
            this.page = val
            this.getDish()
        },
        doSave() {
            this.$axios.post(this.$httpUrl + '/user/register', this.form).then(res => res.data).then(res => {
                console.log(res)
                if (res.code == 200) {

                    this.$message({
                        message: res.msg,
                        type: 'success'
                    });
                    this.centerDialogVisible = false
                    this.resetForm()
                } else {
                    this.$message({
                        message: res.msg,
                        type: 'error'
                    });
                }

            })
        },
        register() {
            this.centerDialogVisible = true;
        },
        login() {
            this.dialogFormVisible = true;
        },
        confirm() {
            this.$refs.loginForm.validate(() => {
                this.$axios.post(this.$httpUrl + '/user/login', this.loginForm).then(res => res.data).then(res => {
                    if (res.code == 200) {
                        this.user = res.data
                        sessionStorage.setItem("CurUser", JSON.stringify(res.data))
                        if (res.data.type == "admin") {
                            this.$router.replace('/admin/Index');
                        }
                        this.$message({
                            message: res.msg,
                            type: 'success'
                        });
                        this.dialogFormVisible = false;
                    } else {
                        this.$message({
                            message: res.msg,
                            type: 'error'
                        });
                    }
                });

            });

        },
        changeType(type) {
            this.typeId = type
            this.currentPage = 1
            this.page = 1
            this.getDish()
        },
        search() {
            this.currentPage = 1
            this.page = 1
            this.getDish()
        },
        resetForm(formName) {
            this.$refs[formName].resetFields();
        },
        getDish() {
            this.$axios.get(this.$httpUrl + '/dish/list?keyword=' + this.searchValue
                + '&page=' + this.page + '&size=' + this.size + '&typeId=' + this.typeId).then(res => res.data).then(res => {
                console.log(res)
                this.data = res.data.records
                this.total = res.data.total
                this.count = this.data.length
            })
        },


    },


    created() {
        this.$axios.get(this.$httpUrl + '/type/list').then(res => res.data).then(res => {
            console.log(res)
            this.types = res.data
        })

        this.user = JSON.parse(sessionStorage.getItem("CurUser"))
        this.getDish()

    }
}
</script>

<style scoped>
.el-divider--vertical {
    height: 30px;
    margin-left: 40px;
}

</style>