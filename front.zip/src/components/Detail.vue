<template>
    <div style="height: 800px;width: 1280px; margin: auto;">
        <el-row style="width: 100%">
            <el-col :span="4">
                <div style="background-color: #2F3744 ;height: 80px;color: white;display: flex">
                    <div style="padding-top: 20px;padding-left: 20px">Welcome: Tourists
                        <el-divider direction="vertical" content-position="center"></el-divider>
                    </div>
                </div>
            </el-col>
            <el-col :span="20">
                <div style="background-color: #2F3744 ;height: 80px;">
                    <div style="padding: 20px">
                        <el-breadcrumb separator-class="el-icon-arrow-right">
                            <el-breadcrumb-item :to="{ path: '/' }"><span style="color:white;">Home</span></el-breadcrumb-item>
                            <el-breadcrumb-item :to="{ path: '/detail/'+this.dishId }">Detail</el-breadcrumb-item>
                        </el-breadcrumb>
                    </div>

                </div>
            </el-col>
        </el-row>
        <el-row style="width: 100%;">
            <el-col :span="4">
                <div style="background-color: #2F3744 ;height: 720px">
                    <div style="margin-left: 20px">
                        <el-button type="success" @click="login" v-if="this.user == null" size="mini">Sign in
                        </el-button>
                        <el-button type="success" @click="register" v-if="this.user == null" size="mini">Register
                        </el-button>
                        <el-button type="success" @click="logout" v-if="this.user != null" size="mini">Sign out
                        </el-button>
                    </div>
                    <div style="margin:23px">
                        <el-avatar :size="150" v-if="this.user==null"
                                   src="http://localhost:8888/upload/default.jpg"></el-avatar>
                        <el-avatar :size="150" v-if="this.user!=null" :src="this.user.avatar"></el-avatar>

                        <el-divider></el-divider>
                    </div>
                    <div style="color: white;margin-top: 30px;margin-left: 20px">
                        <p>station number: A1001</p>
                        <p style="margin-top: 30px">people number: 9</p>
                        <p style="margin-top: 30px" v-if="this.user != null">username: {{ this.user.username }}</p>
                    </div>

                </div>
            </el-col>
            <el-col :span="20">
                <div style="background-color: white ;">

                    <div style="display: flex">
                        <div style="min-width: 700px">
                            <br>
                            <div style="margin-left: 50px">
                                <h2>{{ dish.name }}</h2>
                                <br>
                                <el-image :src="dish.image" :preview-src-list="dish.image"
                                          style="width: 100%;height: auto"></el-image>
                                <br>
                                <br>
                                <p>
                                    {{ dish.content }}
                                </p>
                                <br>
                            </div>
                            <br>

                            <el-divider></el-divider>
                            <div style="margin-left: 50px;margin-bottom: 50px">
                                <h2 style="margin-bottom: 50px">RATING ({{ rating }})</h2>
                                <div style="border: #B3C0D1 solid 1px">
                                    <p style="font-size: 16px; margin: 20px ;color: gray">Comment</p>
                                    <el-form :model="commentForm" status-icon ref="commentForm" label-width="100px"
                                             class="ruleForm">
                                        <div style="width: 90%;margin: auto">


                                            <el-input v-model="commentForm.content" type="textarea" placeholder="Comment"
                                                      :rows="8"></el-input>
                                            <div style="display: flex;margin: 50px">
                                                <span style="margin-right: 30px">Rating : </span>
                                                <el-rate v-model="commentForm.rate" show-score text-color="#ff9900"
                                                         score-template="{value}">
                                                </el-rate>
                                                <el-button type="primary" @click="submitComment" style="margin-left: 30%">submit
                                                </el-button>
                                            </div>

                                        </div>
                                        <div style="margin-left: 5%">

                                        </div>

                                    </el-form>

                                    <el-card v-for="c in comments" :key="c" class="box-card"
                                             style="margin: 20px 50px 20px 50px">
                                        <p style="margin-bottom: 10px">{{ c.comment.content }}</p>

                                        <el-rate v-model="c.comment.rating" disabled style="float: right;margin-bottom: 30px">

                                        </el-rate>
                                        <div style="display: flex;margin-top: 30px">
                                            <el-avatar shape="square" :size="50" :src="c.user.avatar" ></el-avatar>
                                            <div style="margin-left: 20px">
                                                <span style="font-size:12px;font-weight: lighter ;color: gray">{{ c.user.username }}</span>
                                                <br>
                                                <span style="font-size:12px;font-weight: lighter ;color: gray">Time: {{ c.comment.time }}</span>
                                            </div>

                                        </div>



                                    </el-card>

                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </el-col>
        </el-row>


        <el-dialog title="Sign in" :visible.sync="dialogFormVisible" center>

            <el-form :model="loginForm" status-icon :rules="rules" ref="loginForm" label-width="100px" class="ruleForm">

                <el-form-item label="username" prop="username">
                    <el-input v-model="loginForm.username"></el-input>
                </el-form-item>

                <el-form-item label="password" prop="password">
                    <el-input type="password" v-model="loginForm.password" auto-complete="off"></el-input>
                </el-form-item>
            </el-form>

            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false; resetForm('loginForm')">cancel</el-button>
                <el-button type="primary" @click="confirm">sign in</el-button>
            </div>
        </el-dialog>

        <el-dialog
                title="Register"
                :visible.sync="centerDialogVisible"
                width="40%"
                center>

            <el-form ref="form" :rules="rules1" :model="form" label-width="100px">
                <el-form-item label="username" prop="username">
                    <el-col :span="20">
                        <el-input v-model="form.username"></el-input>
                    </el-col>
                </el-form-item>
                <el-form-item label="password" prop="password">
                    <el-col :span="20">
                        <el-input v-model="form.password"></el-input>
                    </el-col>
                </el-form-item>
                <el-form-item label="avatar" prop="avatar">
                    <el-col :span="20">
                        <el-upload action="http://localhost:8888/upload"
                                   list-type="picture-card"
                                   :on-preview="preview"
                                   :on-success="handleSuccess"
                                   :limit="1"
                                   :before-upload="beforeUpload">
                            <i class="el-icon-plus"></i>
                        </el-upload>
                    </el-col>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="centerDialogVisible = false">cancel</el-button>
                <el-button type="primary" @click="doSave">confirm</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
export default {
    name: "Detail",
    data() {
        let checkDuplicate = (rule, value, callback) => {
            if (this.form.id) {
                return callback();
            }
            this.$axios.get(this.$httpUrl + "/user/find/username?username=" + this.form.username).then(res => res.data).then(res => {
                if (res.code != 200) {
                    callback()
                } else {
                    callback(new Error('username already exists'));
                }
            })
        };
        return {
            commentForm: {
                content: '',
                rate: 0
            },
            type: {},
            rating: 0,
            comments: [],
            dish: {},
            dishId: '',
            typeId: '',
            types: [],
            menuIndex: 1,
            data: [],
            count: 0,
            user: null,
            dialogFormVisible: false,
            centerDialogVisible: false,
            size: 8,
            page: 1,
            total: 0,
            currentPage: 1,
            loginForm: {
                username: '',
                password: ''
            },
            rules: {
                username: [
                    {required: true, message: 'please enter username', trigger: 'blur'}
                ],
                password: [
                    {required: true, message: 'please enter password', trigger: 'blur'}
                ]
            },
            form: {
                id: '',
                username: '',
                password: '',
                avatar: ''
            },
            rules1: {
                username: [
                    {required: true, message: 'Please enter username', trigger: 'blur'},
                    {min: 3, max: 8, message: '3 to 8 characters long', trigger: 'blur'},
                    {validator: checkDuplicate, trigger: 'blur'}
                ],
                password: [
                    {required: true, message: 'Please enter password', trigger: 'blur'},
                    {min: 3, max: 8, message: '3 to 8 characters long', trigger: 'blur'}
                ],
            },
            searchValue: ''
        }
    },
    methods: {
        submitComment() {
            console.log(this.commentForm)
            if (this.user == null) {
                this.$message({
                    message: 'please login first',
                    type: 'error'
                })
                return
            }
            this.$axios.post(this.$httpUrl + '/comment/add', {
                content: this.commentForm.content,
                rating: this.commentForm.rate,
                dishId: this.dishId,
                userId: this.user.id
            }).then(res => res.data).then(res => {
                if (res.code == 200) {
                    this.$message({
                        message: 'comment successfully',
                        type: 'success'
                    })
                    this.commentForm.content = ''
                    this.commentForm.rate = 0
                    this.getDish();
                } else {
                    this.$message({
                        message: 'comment failed',
                        type: 'error'
                    })
                }
            })
        },
        handleSuccess(res, file) {
            console.log(file.url)
            this.form.avatar = res.data
        },
        preview(file) {
            console.log(file)
        },
        routTo(id) {
            this.$router.push({
                name: 'detail',
                params: {
                    id: id
                }
            })
        },
        beforeUpload(file) {
            const isJPG = file.type === 'image/jpeg';
            const isPNG = file.type === 'image/png';
            const isLt2M = file.size / 1024 / 1024 < 2;

            if (!isJPG && !isPNG) {
                this.$message.error('Upload pictures can only be in JPG or PNG format!');
            }
            if (!isLt2M) {
                this.$message.error('Upload pictures cannot exceed 2MB in size!');
            }
            return (isJPG || isPNG) && isLt2M;
        },
        logout() {
            console.log('logout')
            this.$confirm('Are you sure you want to log out??', 'prompt', {
                confirmButtonText: 'confirm',
                cancelButtonText: 'cancel',
                type: 'warning',
                center: true,

            })
                .then(() => {
                    this.$message({
                        type: 'success',
                        message: 'exit successfully'
                    })

                    this.user = null
                    sessionStorage.clear()
                })
                .catch((e) => {
                    console.log(e)
                    this.$message({
                        type: 'info',
                        message: 'cancel exit'
                    })
                })
        },
        handleCurrentChange(val) {
            this.page = val
            this.getDish()
        },
        doSave() {
            this.$axios.post(this.$httpUrl + '/user/register', this.form).then(res => res.data).then(res => {
                console.log(res)
                if (res.code == 200) {

                    this.$message({
                        message: res.msg,
                        type: 'success'
                    });
                    this.centerDialogVisible = false
                    this.resetForm()
                } else {
                    this.$message({
                        message: res.msg,
                        type: 'error'
                    });
                }

            })
        },
        register() {
            this.centerDialogVisible = true;
        },
        login() {
            this.dialogFormVisible = true;
        },
        confirm() {
            this.$refs.loginForm.validate(() => {
                this.$axios.post(this.$httpUrl + '/user/login', this.loginForm).then(res => res.data).then(res => {
                    if (res.code == 200) {
                        this.user = res.data
                        sessionStorage.setItem("CurUser", JSON.stringify(res.data))
                        if (res.data.type == "admin") {
                            this.$router.replace('/admin/Index');
                        }
                        this.$message({
                            message: res.msg,
                            type: 'success'
                        });
                        this.dialogFormVisible = false;
                    } else {
                        this.$message({
                            message: res.msg,
                            type: 'error'
                        });
                    }
                });

            });

        },
        changeType(type) {
            this.typeId = type
            this.currentPage = 1
            this.page = 1
            this.getDish()
        },
        search() {
            this.currentPage = 1
            this.page = 1
            this.getDish()
        },
        resetForm(formName) {
            this.$refs[formName].resetFields();
        },
        getDish() {
            this.$axios.get(this.$httpUrl + '/dish/detail?dishId=' + this.dishId).then(res => res.data).then(res => {
                this.dish = res.data.dish;
                this.comments = res.data.comments;
                this.rating = res.data.rating;
                this.type = res.data.type;

            })
        },


    },


    created() {
        this.user = JSON.parse(sessionStorage.getItem("CurUser"))

        this.dishId = this.$route.params.id
        this.getDish()

    }
}
</script>

<style scoped>
.el-divider--vertical {
    height: 30px;
    margin-left: 40px;
}


</style>