<template>
    <div>
        <div style="margin-bottom: 5px;">
            <el-input v-model="keyword" placeholder="please input keyword" suffix-icon="el-icon-search"
                      style="width: 200px;"
                      @keyup.enter.native="loadPost"></el-input>
            <el-button type="primary" style="margin-left: 10%;" @click="loadPost">search</el-button>
            <el-button type="success" @click="resetParam">reset</el-button>

            <el-button type="primary" style="margin-left: 5px;" @click="add">add</el-button>
        </div>
        <el-table :data="tableData"
                  :header-cell-style="{ background: '#f2f5fc', color: '#555555' }"
                  border
        >
            <el-table-column prop="id" label="ID" width="60">
            </el-table-column>
            <el-table-column prop="image" label="image" width="150">
                <template slot-scope="scope">
                    <img :src="scope.row.image" alt="" style="width: 100px; height: 100px;">
                </template>
            </el-table-column>
            <el-table-column prop="name" label="name" width="150">
            </el-table-column>
            <el-table-column prop="content" label="content" width="150">
            </el-table-column>
            <el-table-column prop="price" label="price" width="150">
            </el-table-column>
            <el-table-column prop="typeName" label="type" width="150">
            </el-table-column>

            <el-table-column prop="operate" label="operate">
                <template slot-scope="scope">
                    <el-button size="small" type="success" @click="mod(scope.row)">edit</el-button>
                    <el-popconfirm
                            title="Are you sure to delete this?"
                            @confirm="del(scope.row.id)"
                            style="margin-left: 5px;"
                    >
                        <el-button slot="reference" size="small" type="danger">delete</el-button>
                    </el-popconfirm>
                </template>
            </el-table-column>
        </el-table>

        <el-dialog
                title="prompt"
                :visible.sync="centerDialogVisible"
                width="40%"
                center>

            <el-form ref="form" :model="form" label-width="100px">
                <el-form-item label="name" prop="name">
                    <el-col :span="20">
                        <el-input v-model="form.name"></el-input>
                    </el-col>
                </el-form-item>
                <el-form-item label="price" prop="price">
                    <el-col :span="20">
                        <el-input v-model="form.price"></el-input>
                    </el-col>
                </el-form-item>
                <el-form-item label="type" prop="typeId">
                    <el-col :span="20">
                        <el-select v-model="form.typeId" placeholder="please select">
                            <el-option
                                    v-for="item in typeList"
                                    :key="item.id"
                                    :label="item.name"
                                    :value="item.id">
                            </el-option>
                        </el-select>
                    </el-col>
                </el-form-item>
                <el-form-item label="image" prop="image">
                    <el-col :span="20">
                        <el-upload action="http://localhost:8888/upload"
                                   list-type="picture-card"
                                   :on-preview="preview"
                                   :on-success="handleSuccess"
                                   :show-file-list="false"
                                   :before-upload="beforeUpload">
                            <img v-if="imageUrl" :src="imageUrl" class="avatar">
                            <i class="el-icon-plus"></i>
                        </el-upload>
                    </el-col>
                </el-form-item>
                <el-form-item label="content" prop="content">
                    <el-col :span="20">
                        <el-input type="textarea" v-model="form.content" rows="5"></el-input>
                    </el-col>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
    <el-button @click="centerDialogVisible = false">cancel</el-button>
    <el-button type="primary" @click="save">confirm</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
export default {
    name: "BookManage",
    data() {

        return {
            typeList: [],
            imageUrl: '',
            tableData: [],
            pageSize: 10,
            pageNum: 1,
            total: 0,
            keyword: '',
            centerDialogVisible: false,
            form: {
                id: '',
                name: '',
                typeId: '',
                price: '',
                content: '',
                image: ''

            },
        }
    },
    methods: {
        handleSuccess(res, file) {
            console.log(file.url)
            this.form.image = res.data
            this.imageUrl = this.form.image
        },
        preview(file) {
            console.log(file)
        },
        beforeUpload(file) {
            const isJPG = file.type === 'image/jpeg';
            const isPNG = file.type === 'image/png';
            const isLt2M = file.size / 1024 / 1024 < 2;

            if (!isJPG && !isPNG) {
                this.$message.error('Upload pictures can only be in JPG or PNG format!');
            }
            if (!isLt2M) {
                this.$message.error('Upload pictures cannot exceed 2MB in size!');
            }
            return (isJPG || isPNG) && isLt2M;
        },
        resetForm() {
            this.$refs.form.resetFields();
            this.keyword = ''
            this.loadPost();
        },
        del(id) {
            console.log(id)

            this.$axios.get(this.$httpUrl + '/dish/delete?dishId=' + id).then(res => res.data).then(res => {
                console.log(res)
                if (res.code == 200) {

                    this.$message({
                        message: res.msg,
                        type: 'success'
                    });
                    this.loadPost()
                } else {
                    this.$message({
                        message: res.msg,
                        type: 'error'
                    });
                }

            })
        },
        mod(row) {
            console.log(row)

            this.centerDialogVisible = true
            this.$nextTick(() => {
                this.form.id = row.id
                this.form.name = row.name
                this.form.typeId = row.typeId
                this.form.price = row.price
                this.form.content = row.content
                this.form.image = row.image
                this.imageUrl = row.image
            })
        },
        add() {

            this.centerDialogVisible = true
            this.$nextTick(() => {
                this.resetForm()
            })

        },
        doSave() {
            this.$axios.post(this.$httpUrl + '/dish/add', this.form).then(res => res.data).then(res => {
                console.log(res)
                if (res.code == 200) {

                    this.$message({
                        message: res.msg,
                        type: 'success'
                    });
                    this.centerDialogVisible = false
                    this.loadPost()
                    this.resetForm()
                } else {
                    this.$message({
                        message: res.msg,
                        type: 'error'
                    });
                }

            })
            console.log(this.form)
        },
        doMod() {
            this.$axios.post(this.$httpUrl + '/dish/update', this.form).then(res => res.data).then(res => {
                console.log(res)
                if (res.code == 200) {

                    this.$message({
                        message: res.msg,
                        type: 'success'
                    });
                    this.centerDialogVisible = false
                    this.loadPost()
                    this.resetForm()
                } else {
                    this.$message({
                        message: res.msg,
                        type: 'error'
                    });
                }

            })
        },
        save() {
            this.$refs.form.validate((valid) => {
                if (valid) {
                    if (this.form.id) {
                        this.doMod();
                    } else {
                        this.doSave();
                    }
                } else {
                    console.log('error submit!!');
                    return false;
                }
            });

        },
        handleSizeChange(val) {
            this.pageNum = 1
            this.pageSize = val
            this.loadPost()
        },
        handleCurrentChange(val) {
            this.pageNum = val
            this.loadPost()
        },
        resetParam() {
            this.keyword = ''
            this.loadPost()
        },
        loadPost() {
            this.$axios.get(this.$httpUrl + '/dish/find', {
                params: {
                    keyword: this.keyword
                }
            }).then(res => res.data).then(res => {
                console.log(res)
                if (res.code == 200) {
                    this.tableData = res.data
                } else {
                    alert('Failed to get data')
                }

            })
        }
    },
    beforeMount() {
        //this.loadGet();
        this.loadPost()
        this.$axios.get(this.$httpUrl + '/type/list').then(res => res.data).then(res => {
            console.log(res)
            this.typeList = res.data
        })
    }
}
</script>

<style scoped>
.avatar {
    width: 150px;
    height: 150px;
}

</style>