<template>
    <div>
        <el-table :data="tableData"
                  :header-cell-style="{ background: '#f2f5fc', color: '#555555' }"
                  border
        >
            <el-table-column prop="id" label="ID" width="60">
            </el-table-column>
            <el-table-column prop="dishId" label="dishId" width="80">
            </el-table-column>
            <el-table-column prop="userId" label="userId" width="80">
            </el-table-column>
            <el-table-column prop="content" label="content" width="200">
            </el-table-column>
            <el-table-column prop="rating" label="rating" width="150">
                <template slot-scope="scope">
                    <el-rate :value="scope.row.rating" disabled></el-rate>
                </template>
            </el-table-column>
            <el-table-column prop="time" label="time" width="150">
            </el-table-column>

            <el-table-column prop="operate" label="operate">
                <template slot-scope="scope">
                    <el-popconfirm
                        title="Are you sure to delete this?"
                        @confirm="del(scope.row.id)"
                        style="margin-left: 5px;"
                    >
                        <el-button slot="reference" size="small" type="danger">delete</el-button>
                    </el-popconfirm>
                </template>
            </el-table-column>
        </el-table>

    </div></template>

<script>
    export default {
        name: "CommentManage",
        data() {

            return {
                tableData: [],
                pageSize: 10,
                pageNum: 1,
                total: 0,
                keyword: '',
                form: {
                    id: '',
                    bookId: '',
                    userId: '',
                    time: '',
                    rating: '',
                    content: '',


                }
            }
        },
        methods: {
            resetForm() {
                this.$refs.form.resetFields();
                this.keyword = ''
                this.loadPost();
            },
            del(id) {
                console.log(id)

                this.$axios.get(this.$httpUrl + '/comment/delete?commentId=' + id).then(res => res.data).then(res => {
                    console.log(res)
                    if (res.code == 200) {

                        this.$message({
                            message: res.msg,
                            type: 'success'
                        });
                        this.loadPost()
                    } else {
                        this.$message({
                            message: res.msg,
                            type: 'error'
                        });
                    }

                })
            },
            resetParam() {
                this.keyword = ''
                this.loadPost()
            },
            loadPost() {
                this.$axios.get(this.$httpUrl + '/comment/list', {
                    params: {
                        pageNum: this.pageNum,
                        pageSize: this.pageSize,
                        keyword: this.keyword
                    }
                }).then(res => res.data).then(res => {
                    console.log(res)
                    if (res.code == 200) {
                        this.tableData = res.data
                    } else {
                        alert('Failed to get data')
                    }

                })
            }
        },
        beforeMount() {
            //this.loadGet();
            this.loadPost()
        }
    }
</script>

<style scoped>

</style>