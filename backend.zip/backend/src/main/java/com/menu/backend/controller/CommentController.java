package com.menu.backend.controller;


import com.menu.backend.common.entity.Result;
import com.menu.backend.entity.Comment;
import com.menu.backend.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author demo
 * @since 2024-01-20
 */
@RestController
@RequestMapping("/comment")
public class CommentController {

    private final CommentService commentService;

    @Autowired
    public CommentController(CommentService commentService) {
        this.commentService = commentService;
    }

    @RequestMapping("/add")
    public Result addComment(@RequestBody Comment comment) {
        return commentService.addComment(comment);
    }

    @RequestMapping("/delete")
    public Result deleteComment(Integer commentId) {
        return commentService.deleteComment(commentId);
    }

    @RequestMapping("/list")
    public Result getCommentList() {
        return commentService.getCommentList();
    }
}
