package com.menu.backend.entity.vo;

import com.menu.backend.entity.Dish;
import com.menu.backend.entity.Type;
import lombok.Data;

import java.util.List;

@Data
public class DishDetail {
    private Dish dish;
    private Type type;
    private List<CommentVo> comments;
    private double rating;
}
