package com.menu.backend.service.impl;

import com.menu.backend.common.entity.Result;
import com.menu.backend.entity.Comment;
import com.menu.backend.mapper.CommentMapper;
import com.menu.backend.service.CommentService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author demo
 * @since 2024-01-20
 */
@Service
public class CommentServiceImpl extends ServiceImpl<CommentMapper, Comment> implements CommentService {
    private final CommentMapper commentMapper;

    @Autowired
    public CommentServiceImpl(CommentMapper commentMapper) {
        this.commentMapper = commentMapper;
    }

    @Override
    public Result addComment(Comment comment) {
        comment.setTime(LocalDateTime.now());
        return Result.succ(commentMapper.insert(comment));
    }

    @Override
    public Result deleteComment(Integer commentId) {
        return Result.succ(commentMapper.deleteById(commentId));
    }

    @Override
    public Result getCommentList() {
        return Result.succ(commentMapper.selectList(null));
    }
}
