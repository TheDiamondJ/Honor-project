package com.menu.backend.service;

import com.menu.backend.common.entity.Result;
import com.menu.backend.entity.Dish;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author demo
 * @since 2024-01-20
 */
public interface DishService extends IService<Dish> {

    Result getDishList(Integer typeId, String keyword, Integer page, Integer size);
    Result getDish(Integer dishId);
    Result addDish(Dish dish);
    Result deleteDish(Integer dishId);
    Result updateDish(Dish dish);
    Result findDish(String keyword);

}
