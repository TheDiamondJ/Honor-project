package com.menu.backend.service;

import com.menu.backend.common.entity.Result;
import com.menu.backend.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author demo
 * @since 2024-01-20
 */
public interface UserService extends IService<User> {
    Result register(User user);
    Result login(User user);
    Result getUserInfo(Integer userId);
    Result findUserByUsername(String username);
    Result updateUserInfo(User user);
    Result findUser(String keyword);
    Result deleteUser(Integer userId);
}
