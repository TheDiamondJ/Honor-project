package com.menu.backend.mapper;

import com.menu.backend.entity.Type;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author demo
 * @since 2024-01-20
 */
@Mapper
public interface TypeMapper extends BaseMapper<Type> {

}
