package com.menu.backend.entity.vo;

import com.menu.backend.entity.Comment;
import com.menu.backend.entity.User;
import lombok.Data;

@Data
public class CommentVo {
    private Comment comment;
    private User user;
}
