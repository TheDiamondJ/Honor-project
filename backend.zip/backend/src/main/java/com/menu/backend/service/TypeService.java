package com.menu.backend.service;

import com.menu.backend.common.entity.Result;
import com.menu.backend.entity.Type;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author demo
 * @since 2024-01-20
 */
public interface TypeService extends IService<Type> {

    Result getTypeList();
    Result addType(Type type);
    Result deleteType(Integer typeId);
    Result updateType(Type type);
    Result findType(String keyword);

}
