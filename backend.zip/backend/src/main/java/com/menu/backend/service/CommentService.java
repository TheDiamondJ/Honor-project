package com.menu.backend.service;

import com.menu.backend.common.entity.Result;
import com.menu.backend.entity.Comment;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author demo
 * @since 2024-01-20
 */
public interface CommentService extends IService<Comment> {
    Result addComment(Comment comment);
    Result deleteComment(Integer commentId);
    Result getCommentList();

}
