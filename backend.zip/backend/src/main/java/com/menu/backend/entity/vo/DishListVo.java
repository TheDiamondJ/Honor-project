package com.menu.backend.entity.vo;

import com.menu.backend.entity.Dish;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class DishListVo extends Dish {
    private String typeName;

}
