package com.menu.backend.controller;


import com.menu.backend.common.entity.Result;
import com.menu.backend.entity.Type;
import com.menu.backend.service.TypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author demo
 * @since 2024-01-20
 */
@RestController
@RequestMapping("/type")
public class TypeController {
    private final TypeService typeService;

    @Autowired
    public TypeController(TypeService typeService) {
        this.typeService = typeService;
    }

    @RequestMapping("/list")
    public Result getTypeList() {
        return typeService.getTypeList();
    }

    @RequestMapping("/add")
    public Result addType(@RequestBody Type type) {
        return typeService.addType(type);
    }

    @RequestMapping("/delete")
    public Result deleteType(Integer typeId) {
        return typeService.deleteType(typeId);
    }

    @RequestMapping("/update")
    public Result updateType(@RequestBody Type type) {
        return typeService.updateType(type);
    }

    @RequestMapping("/find")
    public Result findType(String keyword) {
        return typeService.findType(keyword);
    }
}
