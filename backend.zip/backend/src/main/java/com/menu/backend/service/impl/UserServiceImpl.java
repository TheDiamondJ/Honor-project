package com.menu.backend.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.menu.backend.common.entity.Result;
import com.menu.backend.entity.User;
import com.menu.backend.mapper.UserMapper;
import com.menu.backend.service.UserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author demo
 * @since 2024-01-20
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

    private final UserMapper userMapper;

    @Autowired
    public UserServiceImpl(UserMapper userMapper) {
        this.userMapper = userMapper;
    }

    @Override
    public Result register(User user) {
        userMapper.insert(user);
        return Result.succ(user);
    }

    @Override
    public Result login(User user) {
        User username = userMapper.selectOne(new QueryWrapper<User>().eq("username", user.getUsername()));
        if (username == null) {
            return Result.fail("Username does not exist");
        }
        if (!username.getPassword().equals(user.getPassword())) {
            return Result.fail("Wrong password");
        }
        return Result.succ(username);
    }

    @Override
    public Result getUserInfo(Integer userId) {
        return Result.succ(userMapper.selectById(userId));
    }

    @Override
    public Result findUserByUsername(String username) {
        User user = userMapper.selectOne(new QueryWrapper<User>().eq("username", username));
        return Result.succ(user);
    }

    @Override
    public Result updateUserInfo(User user) {
        return Result.succ(userMapper.updateById(user));
    }

    @Override
    public Result findUser(String keyword) {
        if (keyword == null) {
            return Result.succ(userMapper.selectList(null));
        }
        return Result.succ(userMapper.selectList(new QueryWrapper<User>().like("username", keyword)));
    }

    @Override
    public Result deleteUser(Integer userId) {
        return Result.succ(userMapper.deleteById(userId));
    }
}
