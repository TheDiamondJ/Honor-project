package com.menu.backend.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.menu.backend.common.entity.Result;
import com.menu.backend.entity.Comment;
import com.menu.backend.entity.Dish;
import com.menu.backend.entity.Type;
import com.menu.backend.entity.vo.CommentVo;
import com.menu.backend.entity.vo.DishDetail;
import com.menu.backend.entity.vo.DishListVo;
import com.menu.backend.mapper.CommentMapper;
import com.menu.backend.mapper.DishMapper;
import com.menu.backend.mapper.TypeMapper;
import com.menu.backend.mapper.UserMapper;
import com.menu.backend.service.DishService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author demo
 * @since 2024-01-20
 */
@Service
public class DishServiceImpl extends ServiceImpl<DishMapper, Dish> implements DishService {
    private final DishMapper dishMapper;
    private final CommentMapper commentMapper;
    private final UserMapper userMapper;
    private final TypeMapper typeMapper;

    @Autowired
    public DishServiceImpl(DishMapper dishMapper, CommentMapper commentMapper, UserMapper userMapper, TypeMapper typeMapper) {
        this.dishMapper = dishMapper;
        this.commentMapper = commentMapper;
        this.userMapper = userMapper;
        this.typeMapper = typeMapper;
    }


    @Override
    public Result getDishList(Integer typeId, String keyword, Integer page, Integer size) {
        QueryWrapper<Dish> queryWrapper = new QueryWrapper<>();
        if (typeId != null) {
            queryWrapper.eq("type_id", typeId);
        }
        if (keyword != null) {
            queryWrapper.like("name", keyword);
        }

        IPage<Dish> dishPage = dishMapper.selectPage(new Page<>(page, size), queryWrapper);

        return Result.succ(dishPage);
    }

    @Override
    public Result getDish(Integer dishId) {
        DishDetail dishDetail = new DishDetail();
        Dish dish = dishMapper.selectById(dishId);
        dishDetail.setDish(dish);
        List<Comment> commentList = commentMapper.selectList(new QueryWrapper<Comment>()
                .eq("dish_id", dishId));
        List<CommentVo> comments = new ArrayList<>();
        int rating = 0;
        for (Comment comment : commentList) {
            CommentVo commentVo = new CommentVo();
            commentVo.setComment(comment);
            commentVo.setUser(userMapper.selectById(comment.getUserId()));
            comments.add(commentVo);
            rating += comment.getRating();
        }
        dishDetail.setComments(comments);
        double v = (double) rating / comments.size();
        DecimalFormat df = new DecimalFormat("#.0");
        dishDetail.setRating(Double.parseDouble(df.format(v)));
        dishDetail.setType(typeMapper.selectById(dish.getTypeId()));

        return Result.succ(dishDetail);
    }

    @Override
    public Result addDish(Dish dish) {
        return Result.succ(dishMapper.insert(dish));
    }

    @Override
    public Result deleteDish(Integer dishId) {
        return Result.succ(dishMapper.deleteById(dishId));
    }

    @Override
    public Result updateDish(Dish dish) {
        return Result.succ(dishMapper.updateById(dish));
    }

    @Override
    public Result findDish(String keyword) {
        List<Dish> name;
        if (keyword == null) {
            name = dishMapper.selectList(null);
        }else {
            name = dishMapper.selectList(new QueryWrapper<Dish>().like("name", keyword));
        }
        List<DishListVo> dishListVos = new ArrayList<>();
        for (Dish dish : name) {
            DishListVo dishListVo = new DishListVo();
            dishListVo.setTypeName(typeMapper.selectById(dish.getTypeId()).getName());
            BeanUtils.copyProperties(dish, dishListVo);
            dishListVos.add(dishListVo);
        }
        return Result.succ(dishListVos);
    }
}
