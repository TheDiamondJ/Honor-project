package com.menu.backend.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.menu.backend.common.entity.Result;
import com.menu.backend.entity.Type;
import com.menu.backend.mapper.TypeMapper;
import com.menu.backend.service.TypeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author demo
 * @since 2024-01-20
 */
@Service
public class TypeServiceImpl extends ServiceImpl<TypeMapper, Type> implements TypeService {

    private final TypeMapper typeMapper;

    @Autowired
    public TypeServiceImpl(TypeMapper typeMapper) {
        this.typeMapper = typeMapper;
    }

    @Override
    public Result getTypeList() {
        return Result.succ(typeMapper.selectList(null));
    }

    @Override
    public Result addType(Type type) {
        return Result.succ(typeMapper.insert(type));
    }

    @Override
    public Result deleteType(Integer typeId) {
        return Result.succ(typeMapper.deleteById(typeId));
    }

    @Override
    public Result updateType(Type type) {
        return Result.succ(typeMapper.updateById(type));
    }

    @Override
    public Result findType(String keyword) {
        if (keyword == null) {
            return Result.succ(typeMapper.selectList(null));
        }
        return Result.succ(typeMapper.selectList(new QueryWrapper<>(new Type()).like("name", keyword)));
    }
}
