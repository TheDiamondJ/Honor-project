package com.menu.backend.controller;


import com.menu.backend.common.entity.Result;
import com.menu.backend.entity.User;
import com.menu.backend.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author demo
 * @since 2024-01-20
 */
@RestController
@RequestMapping("/user")
public class UserController {
    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @RequestMapping("/login")
    public Result login(@RequestBody User user) {
        return userService.login(user);
    }

    @RequestMapping("/register")
    public Result register(@RequestBody User user) {
        return userService.register(user);
    }

    @RequestMapping("/info")
    public Result getUserInfo(Integer userId) {
        return userService.getUserInfo(userId);
    }

    @RequestMapping("/find")
    public Result findUserByUsername(String username) {
        return userService.findUserByUsername(username);
    }

    @RequestMapping("/update")
    public Result updateUserInfo(@RequestBody User user) {
        return userService.updateUserInfo(user);
    }

    @RequestMapping("/delete")
    public Result deleteUser(Integer userId) {
        return userService.deleteUser(userId);
    }

    @RequestMapping("/find/keyword")
    public Result findUser(String keyword) {
        return userService.findUser(keyword);
    }
}
