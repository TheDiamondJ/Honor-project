package com.menu.backend.controller;


import com.menu.backend.common.entity.Result;
import com.menu.backend.entity.Dish;
import com.menu.backend.service.DishService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author demo
 * @since 2024-01-20
 */
@RestController
@RequestMapping("/dish")
public class DishController {
    private final DishService dishService;

    @Autowired
    public DishController(DishService dishService) {
        this.dishService = dishService;
    }

    @RequestMapping("/list")
    public Result getDishList(Integer typeId, String keyword, Integer page, Integer size) {
        return dishService.getDishList(typeId, keyword, page, size);
    }

    @RequestMapping("/detail")
    public Result getDish(Integer dishId) {
        return dishService.getDish(dishId);
    }

    @RequestMapping("/add")
    public Result addDish(@RequestBody Dish dish) {
        return dishService.addDish(dish);
    }

    @RequestMapping("/delete")
    public Result deleteDish(Integer dishId) {
        return dishService.deleteDish(dishId);
    }

    @RequestMapping("/update")
    public Result updateDish(@RequestBody Dish dish) {
        return dishService.updateDish(dish);
    }

    @RequestMapping("/find")
    public Result findDish(String keyword) {
        return dishService.findDish(keyword);
    }
}
